<?php
if(isset($_REQUEST["param"]))
{
	global $wpdb;
	switch($_REQUEST["param"])
	{
		case "add_new_user":
		parse_str($_REQUEST["data"],$form_data);
		$data = array();
		$data["name"] = $form_data["user-first-name"];
		$data["email"] = $form_data["email"];
		$wpdb->insert("plugin_tabel",$data);
		break;
		
		case "delete_user":
		$data_id = $_REQUEST["data"];
		$where = array();
		$where["id"] = $data_id;
		$wpdb->delete("plugin_tabel",$where);
		break;
	}
}
die();
?>