<div class="new-user" style="text-align: center">
    <form id="add-new-user" name="add-new-user">
        <label>first name :</label> <input type="text" name="user-first-name" id="user-first-name" required><br>
        <label>email :</label> <input type="text" name="email" id="email" required><br>
        <input type="submit" name="submit" value="submit">
     </form>
</div>
<script type="text/javascript">
jQuery("#add-new-user").validate
({
	submitHandler:function(form)
	{
		jQuery.post(ajaxurl,
		{
			data: jQuery("#add-new-user").serialize(),
			param:"add_new_user",
			action: "plugin_action",
		},
		function(data)
		{
			alert("data saved");
		});
	}
});
</script>