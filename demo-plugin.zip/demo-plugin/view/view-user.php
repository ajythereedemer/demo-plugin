<?php
global $wpdb;
$data_result = $wpdb->get_results
(
	"select * from plugin_tabel"
);
?>
<table border=1>
<tr>
<th>Name</th>
<th>Email</th>
<th>actions</th>
</tr>
<?php
foreach($data_result as $key=>$value)
{
?>
<tr>
<td><?php echo $value->name?></td>
<td><?php echo $value->email?></td>
<td><a href="admin.php?page=add_new_user&<?php echo $value->id;?>">edit</a> | <a href="#" onclick="delete_user(<?php echo $value->id;?>)">delete</a></td>
<tr>
<?php
}
?>
<table>
<script type="text/javascript">
function delete_user(id)
{
	jQuery.post(ajaxurl,
		{
			data: id,
			param:"delete_user",
			action: "plugin_action",
		},
		function(data)
		{
			alert(data);
			window.location.reload();
		});
}
</script>

